<?php

namespace App\Http\Controllers;


use App\Models\Degree;
use App\Models\Program;
use App\Models\Department;
use App\Models\University;
use Illuminate\Http\Request;
use App\Exports\ProgramsExport;
use Barryvdh\DomPDF\Facade\PDF; 
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;

class ProgramController extends Controller
{
    /**
     * Display a listing of the programs.
     */
    public function index(Request $request)
    {
        // Get all filter parameters
        $search = $request->input('search', '');
        $universityFilter = $request->input('university_id', []);
        $departmentFilter = $request->input('department', []);
        $degreeFilter = $request->input('degree', []);
        $statusFilter = $request->input('status');
        $languageFilter = $request->input('language');
        $shiftTypeFilter = $request->input('shift_type');
        $minPrice = $request->input('min_price');
        $maxPrice = $request->input('max_price');
        $minDiscount = $request->input('min_discount');
        $maxDiscount = $request->input('max_discount');
        
        $query = Program::with('university');
        
        // Apply search filter
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('department', 'like', "%{$search}%")
                  ->orWhereHas('university', function ($uniQuery) use ($search) {
                      $uniQuery->where('name', 'like', "%{$search}%");
                  });
            });
        }
        
        // Apply university filter (now handles multiple selections)
        if (!empty($universityFilter)) {
            $query->whereIn('university_id', $universityFilter);
        }
        
        // Apply department filter (now handles multiple selections)
        if (!empty($departmentFilter)) {
            $query->whereIn('department', $departmentFilter);
        }
        
        // Apply degree filter (now handles multiple selections)
        if (!empty($degreeFilter)) {
            $query->whereIn('degree', $degreeFilter);
        }
        
        // Apply status filter
        if ($statusFilter) {
            $query->where('status', $statusFilter);
        }
        
        // Apply language filter
        if ($languageFilter) {
            $query->where('language', $languageFilter);
        }
        
        // Apply shift type filter
        if ($shiftTypeFilter) {
            $query->where('shift_type', $shiftTypeFilter);
        }
        
        // Apply price range filters
        if ($minPrice !== null) {
            $query->where('after_discount', '>=', $minPrice);
        }
        
        if ($maxPrice !== null) {
            $query->where('after_discount', '<=', $maxPrice);
        }
        
        // Calculate and filter by discount percentage
        if ($minDiscount !== null || $maxDiscount !== null) {
            // We need to use a raw query to filter by the calculated discount percentage
            $query->addSelect(DB::raw('*, ROUND(((before_discount - after_discount) / before_discount * 100), 2) as discount_percentage'));
            
            if ($minDiscount !== null) {
                $query->having('discount_percentage', '>=', $minDiscount);
            }
            
            if ($maxDiscount !== null) {
                $query->having('discount_percentage', '<=', $maxDiscount);
            }
        } else {
            // Always add the discount_percentage calculation
            $query->addSelect(DB::raw('*, ROUND(((before_discount - after_discount) / before_discount * 100), 2) as discount_percentage'));
        }
        
        // Get paginated results
        $programs = $query->latest()->paginate(10)->withQueryString();
        
        // Get data for filter dropdowns
        $universities = University::where('is_active', true)->orderBy('name')->get();
        $departments = Program::select('department')->distinct()->orderBy('department')->pluck('department');
        $degrees = Degree::all();
        $statuses = Program::getStatuses();
        
        // Calculate statistics for dashboard
        $totalPrograms = Program::count();
        $activePrograms = Program::where('status', 'Active')->count();
        $totalUniversities = University::where('is_active', true)->count();
        $totalDepartments = Program::select('department')->distinct()->count();
        
        return view('admin.programs.index', compact(
            'programs',
            'universities',
            'departments',
            'degrees',
            'statuses',
            'search',
            'universityFilter',
            'departmentFilter',
            'degreeFilter',
            'statusFilter',
            'languageFilter',
            'shiftTypeFilter',
            'minPrice',
            'maxPrice',
            'minDiscount',
            'maxDiscount',
            'totalPrograms',
            'activePrograms',
            'totalUniversities',
            'totalDepartments'
        ));
    }

    /**
     * Show the form for creating a new program.
     */
    public function create()
    {
        $universities = University::where('is_active', true)->orderBy('name')->get();
        $degrees = Degree::all();
        $languages = Program::getLanguages();
        $shiftTypes = Program::getShiftTypes();
        $statuses = Program::getStatuses();
        $departments = Department::all();

        return view('admin.programs.create', compact('universities', 'departments','degrees', 'languages', 'shiftTypes', 'statuses'));
    }

    /**
     * Store a newly created program in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'university_id' => 'required|exists:universities,id',
            'department' => 'required|string|max:255',
            'degree' => 'required|string|max:255',
            'language' => 'required|string|max:255',
            'before_discount' => 'required|numeric|min:0',
            'after_discount' => 'required|numeric|min:0|lte:before_discount',
            'cash_discount' => 'nullable|numeric|min:0',
            'deposit_payment' => 'nullable|numeric|min:0',
            'shift_type' => 'required|string|max:255',
            'siblings_discount' => 'nullable|numeric|min:0|max:100',
            'status' => 'required|string|max:255',
        ]);

        // Set default values for nullable fields
        $validated['cash_discount'] = $validated['cash_discount'] ?? 0;
        $validated['deposit_payment'] = $validated['deposit_payment'] ?? 0;
        $validated['siblings_discount'] = $validated['siblings_discount'] ?? 0;

        Program::create($validated);

        return redirect()->route('admin.programs.index')
            ->with('success', 'Program created successfully.');
    }
   /**
 * Export programs data to PDF
 *
 * @param Request $request
 * @return \Illuminate\Http\Response
 */
public function exportPdf(Request $request)
{
    // Get filter parameters
    $search = $request->input('search');
    $universityFilter = $request->input('university_id');
    $degreeFilter = $request->input('degree');
    $statusFilter = $request->input('status');
    $departmentFilter = $request->input('department');
    $languageFilter = $request->input('language');
    $shiftTypeFilter = $request->input('shift_type');
    $minPrice = $request->input('min_price');
    $maxPrice = $request->input('max_price');
    $minDiscount = $request->input('min_discount');
    $maxDiscount = $request->input('max_discount');
   
    // Build the query with filters
    $query = Program::with('university')
        ->when($search, function ($q) use ($search) {
            return $q->where('department', 'like', "%{$search}%");
        })
        ->when($universityFilter, function ($q) use ($universityFilter) {
            return $q->where('university_id', $universityFilter);
        })
        ->when($degreeFilter, function ($q) use ($degreeFilter) {
            return $q->where('degree', $degreeFilter);
        })
        ->when($statusFilter, function ($q) use ($statusFilter) {
            return $q->where('status', $statusFilter);
        })
        ->when($departmentFilter, function ($q) use ($departmentFilter) {
            return $q->where('department', $departmentFilter);
        })
        ->when($languageFilter, function ($q) use ($languageFilter) {
            return $q->where('language', $languageFilter);
        })
        ->when($shiftTypeFilter, function ($q) use ($shiftTypeFilter) {
            return $q->where('shift_type', $shiftTypeFilter);
        })
        ->when($minPrice, function ($q) use ($minPrice) {
            return $q->where('after_discount', '>=', $minPrice);
        })
        ->when($maxPrice, function ($q) use ($maxPrice) {
            return $q->where('after_discount', '<=', $maxPrice);
        })
        ->when($minDiscount, function ($q) use ($minDiscount) {
            return $q->where('discount_percentage', '>=', $minDiscount);
        })
        ->when($maxDiscount, function ($q) use ($maxDiscount) {
            return $q->where('discount_percentage', '<=', $maxDiscount);
        });
   
    // Get programs based on current filters
    $programs = $query->get();
   
    // Process university logos to base64 for reliable PDF rendering
    foreach ($programs as $program) {
        if (isset($program->university) && $program->university->logo) {
            // Remove "storage/" prefix if it exists
            $logoPath = str_replace('storage/', '', $program->university->logo);
           
            // Build the full path to the storage file
            $path = storage_path('app/public/' . $logoPath);
           
            if (file_exists($path)) {
                $type = pathinfo($path, PATHINFO_EXTENSION);
                $data = file_get_contents($path);
                $program->university->logo_base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
            } else {
                $program->university->logo_base64 = null;
            }
        } elseif (isset($program->university)) {
            $program->university->logo_base64 = null;
        }
        
        // Calculate discount percentage if not already set
        if (!isset($program->discount_percentage) && $program->before_discount > 0) {
            $program->discount_percentage = round(100 - (($program->after_discount / $program->before_discount) * 100));
        }
    }
   
    // Get information for header/filters
    $universities = University::all();
    $universityName = $universityFilter ? $universities->where('id', $universityFilter)->first()->name : 'All';
    
    // Get department name if filter is applied
    $departmentName = $departmentFilter ?: null;
    
    // Language name
    $languageName = $languageFilter ?: 'All';
    
    // Shift type name
    $shiftTypeName = $shiftTypeFilter ?: 'All';
   
    // Get the company logo
    $companyLogoPath = public_path('logo.jpg');
    $companyLogo = '';
    if (file_exists($companyLogoPath)) {
        $type = pathinfo($companyLogoPath, PATHINFO_EXTENSION);
        $data = file_get_contents($companyLogoPath);
        $companyLogo = 'data:image/' . $type . ';base64,' . base64_encode($data);
    }
   
    $degrees = [
        'bachelors' => 'Bachelors',
        'masters' => 'Masters',
        'phd' => 'PhD',
        // Add other degrees as needed
    ];
    $degreeName = $degreeFilter ? ($degrees[$degreeFilter] ?? $degreeFilter) : 'All';
   
    $statuses = [
        'Active' => 'Active',
        'Inactive' => 'Inactive',
        'Pending' => 'Pending',
        // Add other statuses as needed
    ];
    $statusName = $statusFilter ? ($statuses[$statusFilter] ?? $statusFilter) : 'All';
   
    // Create PDF
    $pdf = app('dompdf.wrapper');
    $pdf->getDomPDF()->set_option('isHtml5ParserEnabled', true);
    $pdf->getDomPDF()->set_option('isRemoteEnabled', true);
    $pdf->getDomPDF()->set_option('enable_php', true); // Enable PHP for page numbering
   
    $pdf->loadView('admin.programs.pdf', [
        'programs' => $programs,
        'search' => $search,
        'universityName' => $universityName,
        'departmentName' => $departmentName,
        'degreeName' => $degreeName,
        'statusName' => $statusName,
        'languageName' => $languageName,
        'shiftTypeName' => $shiftTypeName,
        'companyLogo' => $companyLogo,
        'date' => now()->format('F d, Y, h:i A')
    ]);
   
    // Use landscape orientation for better fit 
    $pdf->setPaper('a4', 'landscape');
   
    return $pdf->download('programs_report_' . date('Y-m-d_H-i-s') . '.pdf');
}
    public function show(Program $program)
    {
        $program->load('university');
        
        return view('admin.programs.show', compact('program'));
    }

    /**
     * Show the form for editing the specified program.
     */
    public function edit(Program $program)
    {
        $universities = University::where('is_active', true)->orderBy('name')->get();
        $languages = Program::getLanguages();
        $shiftTypes = Program::getShiftTypes();
        $statuses = Program::getStatuses();
        $departments = Department::all();
        $degrees = Degree::all();

        return view('admin.programs.edit', compact('departments','program', 'universities', 'degrees', 'languages', 'shiftTypes', 'statuses'));
    }

    /**
     * Update the specified program in storage.
     */
    public function update(Request $request, Program $program)
    {
        $validated = $request->validate([
            'university_id' => 'required|exists:universities,id',
            'department' => 'required|string|max:255',
            'degree' => 'required|string|max:255',
            'language' => 'required|string|max:255',
            'before_discount' => 'required|numeric|min:0',
            'after_discount' => 'required|numeric|min:0|lte:before_discount',
            'cash_discount' => 'nullable|numeric|min:0',
            'deposit_payment' => 'nullable|numeric|min:0',
            'shift_type' => 'required|string|max:255',
            'siblings_discount' => 'nullable|numeric|min:0|max:100',
            'status' => 'required|string|max:255',
        ]);

        // Set default values for nullable fields
        $validated['cash_discount'] = $validated['cash_discount'] ?? 0;
        $validated['deposit_payment'] = $validated['deposit_payment'] ?? 0;
        $validated['siblings_discount'] = $validated['siblings_discount'] ?? 0;

        $program->update($validated);

        return redirect()->route('admin.programs.index')
            ->with('success', 'Program updated successfully.');
    }

    /**
     * Remove the specified program from storage.
     */
    public function destroy(Program $program)
    {
        $program->delete();

        return redirect()->route('admin.programs.index')
            ->with('success', 'Program deleted successfully.');
    }

    /**
     * Toggle program status between Active and Inactive.
     */
    public function toggleStatus(Program $program)
    {
        $program->status = ($program->status === 'Active') ? 'Inactive' : 'Active';
        $program->save();
        
        return redirect()->back()
            ->with('success', 'Program status updated successfully.');
    }
}