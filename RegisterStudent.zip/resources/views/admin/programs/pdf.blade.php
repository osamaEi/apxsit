{{-- resources/views/admin/programs/pdf.blade.php --}}
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Programs List</title>
    <style>
        /* Main Document Styling */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            font-size: 12px;
            line-height: 1.5;
            color: #333;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }
        
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 2px solid #8E2989;
            margin-bottom: 20px;
        }
        
        .header-logo {
            height: 60px;
            width: auto;
        }
        
        .header-title {
            text-align: center;
            flex-grow: 1;
        }
        
        h1 {
            font-size: 24px;
            color: #8E2989;
            margin: 0;
            font-weight: 600;
        }
        
        .document-meta {
            text-align: right;
            color: #666;
            font-size: 11px;
            line-height: 1.4;
        }
        
        /* Filter Section */
        .filter-info {
            background-color: #f9f9f9;
            border-radius: 6px;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-left: 4px solid #FF4A60;
            font-size: 12px;
        }
        
        .filter-title {
            font-weight: bold;
            color: #FF4A60;
            margin-right: 8px;
        }
        
        .filter-value {
            font-weight: 600;
        }
        
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        thead {
            background-color: #8E2989;
            color: white;
        }
        
        th {
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            border: none;
        }
        
        td {
            padding: 10px;
            vertical-align: middle;
            border-bottom: 1px solid #eee;
            font-size: 12px;
        }
        
        tr:nth-child(even) {
            background-color: #f8f8f8;
        }
        
        /* Special Cells */
        .logo-cell {
            text-align: center;
            width: 80px;
            height: 55px;
            padding: 8px;
        }
        
        .logo-img {
            max-height: 45px;
            max-width: 70px;
            object-fit: contain;
        }
        
        .active {
            color: #198754;
            font-weight: bold;
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            background-color: rgba(25, 135, 84, 0.1);
        }
        
        .inactive {
            color: #dc3545;
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            background-color: rgba(220, 53, 69, 0.1);
        }
        
        .pending {
            color: #fd7e14;
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            background-color: rgba(253, 126, 20, 0.1);
        }
        
        /* Badge styling */
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .badge-info {
            color: #0dcaf0;
            background-color: rgba(13, 202, 240, 0.1);
        }
        
        .badge-success {
            color: #198754;
            background-color: rgba(25, 135, 84, 0.1);
        }
        
        .badge-warning {
            color: #fd7e14;
            background-color: rgba(253, 126, 20, 0.1);
        }
        
        .badge-secondary {
            color: #6c757d;
            background-color: rgba(108, 117, 125, 0.1);
        }
        
        .badge-light {
            color: #212529;
            background-color: rgba(248, 249, 250, 0.1);
        }
        
        .badge-dark {
            color: #212529;
            background-color: rgba(33, 37, 41, 0.1);
        }
        
        .text-nowrap {
            white-space: nowrap;
        }
        
        .text-success {
            color: #198754;
        }
        
        .text-danger {
            color: #dc3545;
        }
        
        .text-muted {
            color: #6c757d;
        }
        
        .small {
            font-size: 85%;
        }
        
        /* Footer */
        .footer {
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            color: #666;
        }
        
        .page-number {
            font-style: italic;
        }
        
        .logo-footer {
            height: 20px;
            vertical-align: middle;
            margin-right: 5px;
        }
        
        /* Summary Section */
        .summary {
            background-color: #f9f9f9;
            border-radius: 6px;
            padding: 15px;
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        
        .summary-box {
            text-align: center;
            padding: 10px;
            flex: 1;
            min-width: 120px;
        }
        
        .summary-value {
            font-size: 20px;
            font-weight: bold;
            color: #8E2989;
            margin-bottom: 5px;
        }
        
        .summary-label {
            font-size: 11px;
            color: #666;
        }
        
        /* No Results State */
        .no-records {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }
        
        /* Print Specific Styles */
        @page {
            margin: 0.5cm;
        }
        
        @media print {
            body {
                padding: 0;
                margin: 0;
            }
            
            table {
                page-break-inside: auto;
            }
            
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
            
            thead {
                display: table-header-group;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="{{ public_path('logo2.jpg') }}" alt="DEVA Education" class="header-logo">
        <div class="header-title">
            <h1>Programs List</h1>
        </div>
        <div class="document-meta">
            <div>Generated: {{ $date }}</div>
            <div>Report ID: PRG-{{ date('Ymd') }}-{{ rand(1000, 9999) }}</div>
        </div>
    </div>
    
    <div class="filter-info">
        @if(isset($filters) && count(array_filter($filters)) > 0)
            <span class="filter-title">Filters:</span>
            @foreach($filters as $key => $value)
                @if($value)
                    <span>{{ ucfirst(str_replace('_', ' ', $key)) }}: <span class="filter-value">{{ $value }}</span></span>
                    @if(!$loop->last) | @endif
                @endif
            @endforeach
        @else
            <span class="filter-title">Filters:</span> <span>None applied</span>
        @endif
    </div>
   
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>University</th>
                <th>Department</th>
                <th>Degree</th>
                <th>Language</th>
                <th>Shift</th>
                <th>Pricing</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse($programs as $key => $program)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td><strong>{{ $program->university->name ?? 'N/A' }}</strong></td>
                    <td>{{ $program->department }}</td>
                    <td>
                        @if($program->degree == 'Bachelor')
                            <span class="badge badge-info">{{ $program->degree }}</span>
                        @elseif($program->degree == 'Master')
                            <span class="badge badge-success">{{ $program->degree }}</span>
                        @elseif($program->degree == 'PhD')
                            <span class="badge badge-warning">{{ $program->degree }}</span>
                        @else
                            <span class="badge badge-secondary">{{ $program->degree }}</span>
                        @endif
                    </td>
                    <td>{{ $program->language }}</td>
                    <td>
                        <span class="badge {{ $program->shift_type === 'Day' ? 'badge-light' : 'badge-dark' }}">
                            {{ $program->shift_type }}
                        </span>
                    </td>
                    <td class="text-nowrap">
                        <div class="small text-muted">Before: <span class="text-danger">${{ number_format($program->before_discount, 2) }}</span></div>
                        <div>After: <span class="text-success">${{ number_format($program->after_discount, 2) }}</span></div>
                        <div class="small text-muted">Discount: {{ $program->discount_percentage }}%</div>
                    </td>
                    <td>
                        <span class="{{ $program->status === 'Active' ? 'active' : ($program->status === 'Inactive' ? 'inactive' : 'pending') }}">
                            {{ $program->status }}
                        </span>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="no-records">No programs found matching the selected filters.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    
  
   
    <div class="footer">
        <div>
            <img src="{{ public_path('logo2.jpg') }}" alt="DEVA Education" class="logo-footer">
            DEVA Education © {{ date('Y') }} | All Rights Reserved
        </div>
        <div class="page-number">Page 1 of 1</div>
    </div>
</body>
</html>