@extends('admin.index')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-graduation-cap mr-1"></i>
                        Programs Management
                    </h3>
             <!-- Updated Export Buttons with All Filter Parameters -->
<div class="card-tools">
    <div class="btn-group">
        <a href="{{ route('admin.programs.export-excel', [
            'search' => request('search'),
            'university_id' => request('university_id'),
            'department' => request('department'),
            'degree' => request('degree'),
            'language' => request('language'),
            'shift_type' => request('shift_type'),
            'status' => request('status'),
            'min_price' => request('min_price'),
            'max_price' => request('max_price'),
            'min_discount' => request('min_discount'),
            'max_discount' => request('max_discount')
        ]) }}" class="btn btn-success btn-sm mr-1">
            <i class="fas fa-file-excel mr-1"></i> Export Excel
        </a>
        <a href="{{ route('admin.programs.export-pdf', [
            'search' => request('search'),
            'university_id' => request('university_id'),
            'department' => request('department'),
            'degree' => request('degree'),
            'language' => request('language'),
            'shift_type' => request('shift_type'),
            'status' => request('status'),
            'min_price' => request('min_price'),
            'max_price' => request('max_price'),
            'min_discount' => request('min_discount'),
            'max_discount' => request('max_discount')
        ]) }}" class="btn btn-danger btn-sm mr-1">
            <i class="fas fa-file-pdf mr-1"></i> Export PDF
        </a>
        @if(auth()->user()->role == 'Admin' || auth()->user()->role == 'Register' )
        <a href="{{ route('admin.programs.create') }}" class="btn btn-primary btn-sm">
            <i class="fas fa-plus mr-1"></i> Add Program
        </a>
        @endif
    </div>
</div>
                </div>
                <div class="card-body">
                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-lg-3 col-md-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3>{{ $totalPrograms ?? $programs->total() }}</h3>
                                    <p>Total Programs</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-list"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3>{{ $activePrograms ?? $programs->where('status', 'Active')->count() }}</h3>
                                    <p>Active Programs</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3>{{ $totalUniversities ?? $universities->count() }}</h3>
                                    <p>Universities</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-university"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3>{{ $totalDepartments ?? $departments->count() }}</h3>
                                    <p>Departments</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-building"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Advanced Search -->
                    <div class="card card-outline card-info mb-4">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-search mr-1"></i> Advanced Search</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body" >
                            <form action="{{ route('admin.programs.index') }}" method="GET" class="row">
                                <div class="col-md-2 mb-2">
                                    <label>University</label>
                                    <select name="university_id[]" class="form-control select2bs4" multiple>
                                        <option value="">All Universities</option>
                                        @foreach($universities as $university)
                                            <option value="{{ $university->id }}" 
                                                {{ in_array($university->id, $universityFilter ?? []) ? 'selected' : '' }}>
                                                {{ $university->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <label>Department</label>
                                    <select name="department[]" class="form-control select2bs4" multiple>
                                        <option value="">All Departments</option>
                                        @foreach($departments as $department)
                                            <option value="{{ $department }}" 
                                                {{ in_array($department, $departmentFilter ?? []) ? 'selected' : '' }}>
                                                {{ $department }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <label>Degree</label>
                                    <select name="degree[]" class="form-control select2bs4" multiple>
                                        <option value="">All Degrees</option>
                                        @foreach($degrees as $key => $value)
                                            <option value="{{ $value->name }}" 
                                                {{ in_array($value->name, $degreeFilter ?? []) ? 'selected' : '' }}>
                                                {{ $value->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <label>Language</label>
                                    <select name="language" class="form-control select2bs4">
                                        <option value="">All Languages</option>
                                        @php
                                            $availableLanguages = isset($languageFilter) 
                                                ? \App\Models\Program::select('language')->distinct()->orderBy('language')->pluck('language')->toArray() 
                                                : $programs->pluck('language')->unique()->sort()->values()->toArray();
                                        @endphp
                                        @foreach($availableLanguages as $language)
                                            <option value="{{ $language }}" {{ $languageFilter == $language ? 'selected' : '' }}>
                                                {{ $language }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <label>Shift Type</label>
                                    <select name="shift_type" class="form-control select2bs4">
                                        <option value="">All Shifts</option>
                                        @php
                                            $availableShiftTypes = isset($shiftTypeFilter) 
                                                ? \App\Models\Program::select('shift_type')->distinct()->orderBy('shift_type')->pluck('shift_type')->toArray() 
                                                : $programs->pluck('shift_type')->unique()->sort()->values()->toArray();
                                        @endphp
                                        @foreach($availableShiftTypes as $shiftType)
                                            <option value="{{ $shiftType }}" {{ $shiftTypeFilter == $shiftType ? 'selected' : '' }}>
                                                {{ $shiftType }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2 mb-2">
                                    <label>Status</label>
                                    <select name="status" class="form-control select2bs4">
                                        <option value="">All Status</option>
                                        @foreach($statuses as $key => $value)
                                            <option value="{{ $key }}" {{ $statusFilter == $key ? 'selected' : '' }}>
                                                {{ $value }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <label>Price Range</label>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input type="number" name="min_price" class="form-control" placeholder="Min Price" value="{{ request('min_price') }}">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="number" name="max_price" class="form-control" placeholder="Max Price" value="{{ request('max_price') }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <label>Discount Range</label>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input type="number" name="min_discount" class="form-control" placeholder="Min %" value="{{ request('min_discount') }}">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="number" name="max_discount" class="form-control" placeholder="Max %" value="{{ request('max_discount') }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-2 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary mr-2">
                                        <i class="fas fa-search mr-1"></i> Search
                                    </button>
                                    <a href="{{ route('admin.programs.index') }}" class="btn btn-secondary">
                                        <i class="fas fa-redo mr-1"></i> Reset
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Flash Messages -->
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle mr-1"></i> {{ session('success') }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    @endif

                    <!-- Programs Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>University</th>
                                    <th>Department</th>
                                    <th>Degree</th>
                                    <th>Language</th>
                                    <th>Shift</th>
                                    <th>
                                        <i class="fas fa-money-bill-wave mr-1"></i> Pricing
                                    </th>
                                    <th>
                                        <i class="fas fa-percent mr-1"></i> Discounts
                                    </th>
                                    <th>Status</th>
                                    <th width="140">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($programs as $key => $program)
                                    <tr>
                                        <td class="text-center">{{ $key+1 }}</td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                         
                                                {{ $program->university->name ?? 'N/A' }}
                                            </div>
                                        </td>
                                        <td>{{ $program->department }}</td>
                                        <td>
                                            @if($program->degree == 'Bachelor')
                                                <span class="badge badge-info">{{ $program->degree }}</span>
                                            @elseif($program->degree == 'Master')
                                                <span class="badge badge-success">{{ $program->degree }}</span>
                                            @elseif($program->degree == 'PhD')
                                                <span class="badge badge-warning">{{ $program->degree }}</span>
                                            @else
                                                <span class="badge badge-secondary">{{ $program->degree }}</span>
                                            @endif
                                        </td>
                                        <td>{{ $program->language }}</td>
                                        <td>
                                            <span class="badge {{ $program->shift_type === 'Day' ? 'badge-light' : 'badge-dark' }}">
                                                <i class="fas {{ $program->shift_type === 'Day' ? 'fa-sun' : 'fa-moon' }} mr-1"></i>
                                                {{ $program->shift_type }}
                                            </span>
                                        </td>
                                        <td>
                                            <div class="text-nowrap">
                                                <div class="text-muted small">Before: <span class="text-danger">${{ number_format($program->before_discount, 2) }}</span></div>
                                                <div class="font-weight-bold">After: <span class="text-success">${{ number_format($program->after_discount, 2) }}</span></div>
                                                <div class="text-muted small">Deposit: ${{ number_format($program->deposit_payment, 2) }}</div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-nowrap">
                                                <div>
                                                    <span class="badge badge-info">
                                                        {{ $program->discount_percentage }}% Off
                                                    </span>
                                                </div>
                                                @if($program->cash_discount > 0)
                                                    <div class="mt-1">
                                                        <span class="badge badge-success">
                                                            Cash: ${{ number_format($program->cash_discount, 2) }}
                                                        </span>
                                                    </div>
                                                @endif
                                                @if($program->siblings_discount > 0 || $program->brothers_discount > 0)
                                                    <div class="mt-1">
                                                        @if($program->siblings_discount > 0)
                                                            <span class="badge badge-warning mr-1">
                                                                Siblings: {{ $program->siblings_discount }}%
                                                            </span>
                                                        @endif
                                                        @if($program->brothers_discount > 0)
                                                            <span class="badge badge-warning">
                                                                Brothers: {{ $program->brothers_discount }}%
                                                            </span>
                                                        @endif
                                                    </div>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge badge-{{ $program->status === 'Active' ? 'success' : ($program->status === 'Inactive' ? 'danger' : 'warning') }} badge-pill px-3 py-2">
                                                <i class="fas fa-{{ $program->status === 'Active' ? 'check-circle' : ($program->status === 'Inactive' ? 'times-circle' : 'exclamation-circle') }} mr-1"></i>
                                                {{ $program->status }}
                                            </span>
                                        </td>
                                        <td>
                                            @if(auth()->user()->role == 'Admin' || auth()->user()->role == 'Register' )

                                            <div class="btn-group">
                                         
                                                <a href="{{ route('admin.programs.edit', $program) }}" class="btn btn-sm btn-primary" title="Edit Program">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="{{ route('admin.programs.toggle-status', $program) }}" class="btn btn-sm btn-{{ $program->status === 'Active' ? 'warning' : 'success' }}" title="{{ $program->status === 'Active' ? 'Deactivate' : 'Activate' }}">
                                                    <i class="fas fa-{{ $program->status === 'Active' ? 'times' : 'check' }}"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal{{ $program->id }}" title="Delete Program">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                            @endif

                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="deleteModal{{ $program->id }}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel{{ $program->id }}" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-danger text-white">
                                                            <h5 class="modal-title" id="deleteModalLabel{{ $program->id }}">
                                                                <i class="fas fa-exclamation-triangle mr-1"></i> Confirm Delete
                                                            </h5>
                                                            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Are you sure you want to delete the program:</p>
                                                            <div class="alert alert-warning">
                                                                <strong>{{ $program->department }} ({{ $program->degree }})</strong><br>
                                                                from <strong>{{ $program->university->name ?? 'Unknown University' }}</strong>
                                                            </div>
                                                            <p class="text-danger"><small><i class="fas fa-info-circle mr-1"></i> This action cannot be undone.</small></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                                <i class="fas fa-times mr-1"></i> Cancel
                                                            </button>
                                                            <form action="{{ route('admin.programs.destroy', $program) }}" method="POST">
                                                                @csrf
                                                                @method('DELETE')
                                                                <button type="submit" class="btn btn-danger">
                                                                    <i class="fas fa-trash mr-1"></i> Delete
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="10" class="text-center py-4">
                                            <div class="empty-state">
                                                <i class="fas fa-database fa-3x text-muted mb-3"></i>
                                                <h5>No programs found</h5>
                                                <p class="text-muted">Try adjusting your search criteria or add a new program.</p>
                                                @if(auth()->user()->role == 'Admin' || auth()->user()->role == 'Register' )

                                                <a href="{{ route('admin.programs.create') }}" class="btn btn-primary mt-2">
                                                    <i class="fas fa-plus mr-1"></i> Add Program
                                                </a>
@endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-muted">
                                @if($programs->total() > 0)
                                    Showing {{ $programs->firstItem() }} to {{ $programs->lastItem() }} of {{ $programs->total() }} entries
                                @else
                                    Showing 0 to 0 of 0 entries
                                @endif
                            </span>
                        </div>
                        <div>
                            {{ $programs->appends(request()->query())->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CSS Styles -->
<style>
    .small-box {
        border-radius: 0.5rem;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
        transition: transform 0.3s;
    }
    .small-box:hover {
        transform: translateY(-5px);
    }
    .empty-state {
        padding: 2rem;
        text-align: center;
    }
    .badge-pill {
        font-size: 0.85rem;
    }
    .table td {
        vertical-align: middle;
    }
</style>

<!-- Select2 -->
<link rel="stylesheet" href="{{ asset('plugins/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">

<!-- Select2 and CardWidget JS -->
<script src="{{ asset('plugins/select2/js/select2.full.min.js') }}"></script>
<script>
$(function() {
    // Initialize Select2 Elements
    $('.select2bs4').select2({
        theme: 'bootstrap4'
    });
    
    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert-dismissible').fadeOut('slow');
    }, 5000);
});
</script>
@endsection