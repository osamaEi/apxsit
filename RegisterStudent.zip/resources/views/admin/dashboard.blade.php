@extends('admin.index')

@section('content')
<div class="dashboard-container">
    <!-- Analytics Overview -->
    <div class="analytics-overview">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="overview-heading">
                        <h1 class="welcome-heading">Dashboard Overview</h1>
                        <p class="welcome-subtext">
                            <span class="text-highlighted">{{ now()->format('l, F d, Y') }}</span> — 
                            <span class="stats-summary">Total <strong>{{ $programStats['totalPrograms'] }}</strong> programs across <strong>{{ $universityStats['totalUniversities'] }}</strong> universities.</span>
                        </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="quick-actions text-lg-right">
                        <div class="btn-group">
                       
                 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- Key Metrics -->
            <div class="section key-metrics">
                <div class="container-fluid px-1">
                    <div class="row flex-nowrap overflow-auto pb-2">
                        <div class="col-auto">
                            <div class="card metric-card students-card h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="metric-icon bg-light rounded-circle p-2 me-3">
                                            <i class="fas fa-user-graduate text-primary"></i>
                                        </div>
                                        <div>
                                            <h3 class="h5 mb-0 fw-bold">{{ $studentCount }}</h3>
                                            <p class="text-muted small mb-0">Students</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small">
                                        <div class="text-success">
                                            <i class="fas fa-arrow-up"></i> {{ rand(3, 15) }}%
                                        </div>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-auto">
                            <div class="card metric-card universities-card h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="metric-icon bg-light rounded-circle p-2 me-3">
                                            <i class="fas fa-university text-purple"></i>
                                        </div>
                                        <div>
                                            <h3 class="h5 mb-0 fw-bold">{{ $universityStats['totalUniversities'] }}</h3>
                                            <p class="text-muted small mb-0">Universities</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small">
                                        <div class="text-success">
                                            <i class="fas fa-arrow-up"></i> {{ rand(1, 8) }}%
                                        </div>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-auto">
                            <div class="card metric-card programs-card h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="metric-icon bg-light rounded-circle p-2 me-3">
                                            <i class="fas fa-graduation-cap text-info"></i>
                                        </div>
                                        <div>
                                            <h3 class="h5 mb-0 fw-bold">{{ $programStats['totalPrograms'] }}</h3>
                                            <p class="text-muted small mb-0">Programs</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small">
                                        <div class="text-{{ rand(0, 1) ? 'success' : 'danger' }}">
                                            <i class="fas fa-arrow-{{ rand(0, 1) ? 'up' : 'down' }}"></i> {{ rand(1, 10) }}%
                                        </div>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-auto">
                            <div class="card metric-card applications-card h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="metric-icon bg-light rounded-circle p-2 me-3">
                                            <i class="fas fa-clipboard-list text-success"></i>
                                        </div>
                                        <div>
                                            <h3 class="h5 mb-0 fw-bold">{{ $applicationCount }}</h3>
                                            <p class="text-muted small mb-0">Applications</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small">
                                        <div class="text-success">
                                            <i class="fas fa-arrow-up"></i> {{ rand(5, 20) }}%
                                        </div>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-auto">
                            <div class="card metric-card completed-card h-100">
                                <div class="card-body">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="metric-icon bg-light rounded-circle p-2 me-3">
                                            <i class="fas fa-check-circle text-warning"></i>
                                        </div>
                                        <div>
                                            <h3 class="h5 mb-0 fw-bold">{{ $applicationCompleted }}</h3>
                                            <p class="text-muted small mb-0">Completed</p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small">
                                        <div class="text-success">
                                            <i class="fas fa-arrow-up"></i> {{ rand(5, 20) }}%
                                        </div>
                                        <span class="text-muted">vs last month</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
            /* Just a few minimal custom styles that Bootstrap doesn't provide */
            .text-purple {
                color: #8E2989;
            }
            
            .overflow-auto {
                scrollbar-width: thin;
                scrollbar-color: #dee2e6 #f8f9fa;
            }
            
            .overflow-auto::-webkit-scrollbar {
                height: 6px;
            }
            
            .overflow-auto::-webkit-scrollbar-track {
                background: #f8f9fa;
            }
            
            .overflow-auto::-webkit-scrollbar-thumb {
                background-color: #dee2e6;
                border-radius: 20px;
            }
            
            /* Optional: Add colored borders to cards */
            .students-card {
                border-top: 3px solid #0d6efd;
            }
            
            .universities-card {
                border-top: 3px solid #8E2989;
            }
            
            .programs-card {
                border-top: 3px solid #0dcaf0;
            }
            
            .applications-card {
                border-top: 3px solid #198754;
            }
            
            .completed-card {
                border-top: 3px solid #ffc107;
            }
            </style>
            
            <!-- Main Dashboard Section -->
            <div class="row">
                <!-- Left Column -->
                <div class="col-lg-8">
                    <!-- Student Status Overview Chart -->
                    <div class="section">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-chart-bar mr-2"></i>Student Applications
                                </h3>
                                <div class="card-tools">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-secondary active period-selector" data-period="monthly">Monthly</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary period-selector" data-period="quarterly">Quarterly</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary period-selector" data-period="yearly">Yearly</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="studentApplicationsChart" height="280"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
 
                    
                    <!-- Recent Applications Table -->
                    <div class="section">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-clipboard-check mr-2"></i>Recent Students
                                </h3>
                                <div class="card-tools">
                                    <a href="{{ route('admin.students.index') }}" class="btn btn-sm btn-primary">
                                        View All Applications
                                    </a>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Program</th>
                                                <th>University</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($students as $user)
                                                <tr>
                                                    <td>
                                                        <div class="user-info">
                                                            <div class="user-avatar">
                                                                {{ substr($user->name, 0, 2) }}
                                                            </div>
                                                            <div class="user-details">
                                                                <div class="user-name">{{ $user->name }}</div>
                                                                <div class="user-email">{{ $user->email }}</div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>Sample Program</td>
                                                    <td>Sample University</td>
                                                    <td>
                                                        <span class="status-badge status-new">
                                                            New
                                                        </span>
                                                    </td>
                                                    <td>{{ $user->created_at->format('M d, Y') }}</td>
                                                  
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div class="col-lg-4">
                    <!-- Student Applications Status -->
                    <div class="section">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-tasks mr-2"></i>Application Status
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container text-center mb-3">
                                    <canvas id="applicationStatusChart" height="220"></canvas>
                                </div>
                                
                                <div class="status-legends">
                                    <div class="status-legend">
                                        <span class="status-dot bg-primary"></span>
                                        <span class="status-label">New</span>
                                        <span class="status-value">{{ $studentStats['newApplications'] }}</span>
                                    </div>
                                    <div class="status-legend">
                                        <span class="status-dot bg-info"></span>
                                        <span class="status-label">In Review</span>
                                        <span class="status-value">{{ $studentStats['inReviewApplications'] }}</span>
                                    </div>
                                    <div class="status-legend">
                                        <span class="status-dot bg-warning"></span>
                                        <span class="status-label">Pending Documents</span>
                                        <span class="status-value">{{ $studentStats['pendingDocuments'] }}</span>
                                    </div>
                                    <div class="status-legend">
                                        <span class="status-dot bg-success"></span>
                                        <span class="status-label">Accepted</span>
                                        <span class="status-value">{{ $studentStats['acceptedApplications'] }}</span>
                                    </div>
                                    <div class="status-legend">
                                        <span class="status-dot bg-danger"></span>
                                        <span class="status-label">Rejected</span>
                                        <span class="status-value">{{ $studentStats['rejectedApplications'] }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Students by Nationality -->
                    {{-- <div class="section">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-globe mr-2"></i>Top Nationalities
                                </h3>
                            </div>
                            <div class="card-body p-0">
                                <div class="nationality-list">
                                    @php
                                        $countries = [
                                            ['name' => 'United States', 'count' => rand(150, 300), 'flag' => '🇺🇸'],
                                            ['name' => 'China', 'count' => rand(120, 250), 'flag' => '🇨🇳'],
                                            ['name' => 'India', 'count' => rand(100, 220), 'flag' => '🇮🇳'],
                                            ['name' => 'Germany', 'count' => rand(80, 150), 'flag' => '🇩🇪'],
                                            ['name' => 'UK', 'count' => rand(70, 140), 'flag' => '🇬🇧'],
                                            ['name' => 'Canada', 'count' => rand(60, 130), 'flag' => '🇨🇦'],
                                            ['name' => 'France', 'count' => rand(50, 100), 'flag' => '🇫🇷'],
                                        ];
                                        $totalStudents = $studentStats['totalStudents'];
                                    @endphp
                                    
                                    @foreach($countries as $country)
                                        <div class="nationality-item">
                                            <div class="nationality-info">
                                                <span class="country-flag">{{ $country['flag'] }}</span>
                                                <span class="country-name">{{ $country['name'] }}</span>
                                            </div>
                                            <div class="nationality-count">
                                                <span class="count-value">{{ $country['count'] }}</span>
                                                <div class="progress">
                                                    <div class="progress-bar" style="width: {{ ($country['count'] / $totalStudents) * 100 }}%"></div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                            <div class="card-footer bg-white">
                                <a href="#" class="btn btn-outline-primary btn-sm btn-block">
                                    View All Nationalities
                                </a>
                            </div>
                        </div>
                    </div> --}}
                </div>
            </div>
        </div>
    </div>
</div>


<style>
/* Global Styling */
.dashboard-container {
    background-color: #f8f9fa;
    min-height: 100vh;
}

/* Analytics Overview Section */
.analytics-overview {
    background: #7a0066cb;
    padding: 2rem 0;
    margin-bottom: 1.5rem;
    color: white;
}

.welcome-heading {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.welcome-subtext {
    font-size: 0.95rem;
    opacity: 0.9;
}

.text-highlighted {
    font-weight: 500;
}

.quick-actions .btn {
    border-radius: 4px;
    padding: 0.5rem 1rem;
    transition: all 0.3s ease;
}

.btn-outline-primary {
    border-color: rgba(255, 255, 255, 0.6);
    color: white;
}

.btn-outline-primary:hover {
    background-color: rgba(255, 255, 255, 0.1);
    border-color: white;
}

.btn-primary {
    background-color: white;
    border-color: white;
    color: #3a6eff;
}

.btn-primary:hover {
    background-color: rgba(255, 255, 255, 0.9);
    border-color: rgba(255, 255, 255, 0.9);
    color: #3a6eff;
}

/* Main Content Spacing */
.section {
    margin-bottom: 1.5rem;
}

/* Cards */
.card {
    border: none;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

.card-header {
    background-color: #fff;
    border-bottom: 1px solid #f0f0f0;
    padding: 1rem 1.25rem;
}

.card-header .card-title {
    font-size: 1.1rem;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
}

.card-header .card-title i {
    color: #3a6eff;
}

/* Metric Cards */
.key-metrics {
    margin-bottom: 2rem;
}

.metric-card {
    background-color: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    padding: 1.25rem;
    position: relative;
    height: 100%;
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.metric-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.card-content {
    display: flex;
    align-items: center;
    margin-bottom: 1rem;
}

.metric-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin-right: 1rem;
}

.students-card .metric-icon {
    background-color: #EBF3FF;
    color: #3a6eff;
}

.universities-card .metric-icon {
    background-color: #FFF4E5;
    color: #FF9500;
}

.programs-card .metric-icon {
    background-color: #E7F9F0;
    color: #28C76F;
}

.applications-card .metric-icon {
    background-color: #F6ECFF;
    color: #9C27B0;
}

.metric-data {
    flex: 1;
}

.metric-value {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    line-height: 1.1;
}

.metric-label {
    font-size: 0.85rem;
    color: #6c757d;
    margin: 0;
}

.metric-chart {
    height: 40px;
    margin-bottom: 0.75rem;
}

.metric-footer {
    display: flex;
    align-items: center;
    font-size: 0.8rem;
}

.trend {
    font-weight: 500;
    display: flex;
    align-items: center;
    margin-right: 0.5rem;
}

.trend i {
    margin-right: 0.25rem;
}

.trend.up {
    color: #28C76F;
}

.trend.down {
    color: #EA5455;
}

.trend-period {
    color: #6c757d;
}

/* Program Distribution */
.program-distribution {
    padding: 1.25rem;
}

.program-type {
    display: flex;
    align-items: center;
    padding: 1rem;
    background-color: #f8f9fa;
    border-radius: 8px;
    height: 100%;
}

.program-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    margin-right: 1rem;
}

.bachelor .program-icon {
    background-color: #EBF3FF;
    color: #3a6eff;
}

.master .program-icon {
    background-color: #E7F9F0;
    color: #28C76F;
}

.phd .program-icon {
    background-color: #E5F3FF;
    color: #00CFE8;
}

.program-stats {
    flex: 1;
}

.program-count {
    font-size: 1.5rem;
    font-weight: 700;
    margin: 0;
    line-height: 1.1;
}

.program-label {
    font-size: 0.85rem;
    color: #6c757d;
    margin-bottom: 0.5rem;
}

.program-percentage {
    font-size: 0.8rem;
    color: #6c757d;
    margin-top: 0.25rem;
    margin-bottom: 0;
}

.progress {
    height: 6px;
    background-color: #e9ecef;
    border-radius: 10px;
}

.progress-bar {
    border-radius: 10px;
}
.table {
    margin-bottom: 0;
}

.table th {
    border-top: none;
    background-color: #f8f9fb;
    font-weight: 600;
    color: #495057;
    font-size: 0.9rem;
    padding: 0.75rem 1rem;
}

.table td {
    padding: 1rem;
    vertical-align: middle;
    border-color: #f0f0f0;
}

.table tr:hover {
    background-color: #f8f9fa;
}

/* User Info in Table */
.user-info {
    display: flex;
    align-items: center;
}

.user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background-color: #e9ecef;
    color: #495057;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    margin-right: 0.75rem;
}

.user-details {
    display: flex;
    flex-direction: column;
}

.user-name {
    font-weight: 500;
    color: #343a40;
}

.user-email {
    font-size: 0.75rem;
    color: #6c757d;
}

/* Status Badges */
.status-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.75rem;
}

.status-badge::before {
    content: '';
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 0.5rem;
}

.status-new {
    background-color: rgba(58, 110, 255, 0.1);
    color: #3a6eff;
}

.status-new::before {
    background-color: #3a6eff;
}

.status-in-review {
    background-color: rgba(0, 207, 232, 0.1);
    color: #00CFE8;
}

.status-in-review::before {
    background-color: #00CFE8;
}

.status-pending-documents {
    background-color: rgba(255, 149, 0, 0.1);
    color: #FF9500;
}

.status-pending-documents::before {
    background-color: #FF9500;
}

.status-accepted {
    background-color: rgba(40, 199, 111, 0.1);
    color: #28C76F;
}

.status-accepted::before {
    background-color: #28C76F;
}

.status-rejected {
    background-color: rgba(234, 84, 85, 0.1);
    color: #EA5455;
}

.status-rejected::before {
    background-color: #EA5455;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 0.5rem;
    justify-content: center;
}

.action-buttons .btn {
    width: 32px;
    height: 32px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
}

/* Status Legends */
.status-legends {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 0.75rem;
}

.status-legend {
    display: flex;
    align-items: center;
    font-size: 0.9rem;
}

.status-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    margin-right: 0.5rem;
}

.status-label {
    margin-right: 0.5rem;
    color: #495057;
}

.status-value {
    font-weight: 600;
    color: #343a40;
    margin-left: auto;
}

/* Nationality List */
.nationality-list {
    padding: 1rem;
}

.nationality-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 0;
    border-bottom: 1px solid #f0f0f0;
}

.nationality-item:last-child {
    border-bottom: none;
}

.nationality-info {
    display: flex;
    align-items: center;
}

.country-flag {
    margin-right: 0.75rem;
    font-size: 1.25rem;
}

.country-name {
    color: #495057;
    font-weight: 500;
}

.nationality-count {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.count-value {
    font-weight: 600;
    color: #343a40;
    margin-bottom: 0.25rem;
}

.nationality-count .progress {
    width: 80px;
    height: 5px;
}

.nationality-count .progress-bar {
    background-color: #3a6eff;
}

/* Quick Stats */
.quick-stat-list {
    padding: 0.5rem 0;
}

.quick-stat-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #f0f0f0;
}

.quick-stat-item:last-child {
    border-bottom: none;
}

.stat-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    margin-right: 1rem;
}

.bg-orange {
    background-color: #FF9500;
}

.bg-teal {
    background-color: #20C997;
}

.bg-purple {
    background-color: #7367F0;
}

.bg-blue {
    background-color: #3a6eff;
}

.stat-info {
    flex: 1;
}

.stat-value {
    font-weight: 600;
    font-size: 1.15rem;
    color: #343a40;
    line-height: 1.1;
}

.stat-label {
    font-size: 0.8rem;
    color: #6c757d;
}

.stat-action {
    margin-left: 0.75rem;
}

/* Period Selector Buttons */
.period-selector {
    font-size: 0.8rem;
    padding: 0.3rem 0.7rem;
}

/* Responsive Adjustments */
@media (max-width: 991.98px) {
    .analytics-overview {
        padding: 1.5rem 0;
    }
    
    .quick-actions {
        margin-top: 1rem;
        text-align: left;
    }
    
    .nationality-count .progress {
        width: 60px;
    }
}

@media (max-width: 767.98px) {
    .program-type-column {
        margin-bottom: 1rem;
    }
    
    .program-type-column:last-child {
        margin-bottom: 0;
    }
    
    .status-legends {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 575.98px) {
    .welcome-heading {
        font-size: 1.5rem;
    }
    
    .metric-value {
        font-size: 1.5rem;
    }
    
    .card-header .card-title {
        font-size: 1rem;
    }
    
    .user-info {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .user-avatar {
        margin-bottom: 0.5rem;
    }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
$(function() {
    // Sparkline Charts for Metric Cards
    const studentsSparklineOptions = {
        series: [{
            name: 'Students',
            data: [580, 610, 590, 620, 650, 630, 660, 690, 720]
        }],
        chart: {
            type: 'area',
            height: 40,
            sparkline: {
                enabled: true
            },
        },
        stroke: {
            curve: 'smooth',
            width: 2,
        },
        colors: ['#3a6eff'],
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.7,
                opacityTo: 0.3,
                stops: [0, 90, 100]
            }
        },
        tooltip: {
            fixed: {
                enabled: false
            },
            x: {
                show: false
            },
            marker: {
                show: false
            }
        }
    };
    
    const universitiesSparklineOptions = {
        ...studentsSparklineOptions,
        series: [{
            name: 'Universities',
            data: [30, 29, 32, 35, 33, 38, 39, 40, 41]
        }],
        colors: ['#FF9500'],
    };
    
    const programsSparklineOptions = {
        ...studentsSparklineOptions,
        series: [{
            name: 'Programs',
            data: [120, 125, 130, 128, 135, 140, 145, 150, 155]
        }],
        colors: ['#28C76F'],
    };
    
    const applicationsSparklineOptions = {
        ...studentsSparklineOptions,
        series: [{
            name: 'Applications',
            data: [80, 95, 90, 100, 110, 105, 115, 120, 130]
        }],
        colors: ['#9C27B0'],
    };
    
    new ApexCharts(document.querySelector("#studentsSparkline"), studentsSparklineOptions).render();
    new ApexCharts(document.querySelector("#universitiesSparkline"), universitiesSparklineOptions).render();
    new ApexCharts(document.querySelector("#programsSparkline"), programsSparklineOptions).render();
    new ApexCharts(document.querySelector("#applicationsSparkline"), applicationsSparklineOptions).render();
    
    // Student Applications Chart
    const ctx = document.getElementById('studentApplicationsChart').getContext('2d');
    const studentApplicationsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
            datasets: [
                {
                    label: 'New Applications',
                    data: [65, 59, 80, 81, 56, 55, 40, 60, 70],
                    backgroundColor: '#3a6eff',
                    borderRadius: 6,
                    barPercentage: 0.5,
                },
                {
                    label: 'Accepted',
                    data: [45, 42, 60, 55, 40, 38, 30, 42, 50],
                    backgroundColor: '#28C76F',
                    borderRadius: 6,
                    barPercentage: 0.5,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    grid: {
                        borderDash: [3, 3],
                    },
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 12,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    cornerRadius: 6,
                    padding: 10,
                    caretSize: 6
                }
            }
        }
    });
    
    // Period Selector Functionality
    $('.period-selector').on('click', function() {
        $('.period-selector').removeClass('active');
        $(this).addClass('active');
        
        const period = $(this).data('period');
        
        // Randomly generate new data for demonstration
        const newData = Array.from({length: 9}, () => Math.floor(Math.random() * 50) + 30);
        const acceptedData = newData.map(val => Math.floor(val * 0.7));
        
        studentApplicationsChart.data.datasets[0].data = newData;
        studentApplicationsChart.data.datasets[1].data = acceptedData;
        studentApplicationsChart.update();
    });
    
    // Application Status Chart
    const statusCtx = document.getElementById('applicationStatusChart').getContext('2d');
    const applicationStatusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['New', 'In Review', 'Pending Documents', 'Accepted', 'Rejected'],
            datasets: [{
                data: [{{ $studentStats['newApplications'] ?? rand(50, 150) }}, 
                       {{ $studentStats['inReviewApplications'] ?? rand(70, 180) }}, 
                       {{ $studentStats['pendingDocuments'] ?? rand(40, 120) }}, 
                       {{ $studentStats['acceptedApplications'] ?? rand(100, 250) }}, 
                       {{ $studentStats['rejectedApplications'] ?? rand(30, 80) }}],
                backgroundColor: [
                    '#3a6eff',
                    '#00CFE8',
                    '#FF9500',
                    '#28C76F',
                    '#EA5455'
                ],
                borderWidth: 0,
                cutout: '70%'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    cornerRadius: 6,
                    padding: 10,
                    caretSize: 6
                }
            }
        }
    });
    
    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
@endsection